document.querySelector(".prof-img img").onclick = function(){
    document.querySelector(".open-img").classList.add("op-img");
}
document.querySelector(".open-img").onclick = function(){
    document.querySelector(".open-img").classList.remove("op-img");
}
